CREATE TABLE student
(
  id serial NOT NULL,
  email text,
  lms_id integer
);

CREATE TABLE course
(
  id serial NOT NULL,
  coursename text,
  lms_id integer
);

