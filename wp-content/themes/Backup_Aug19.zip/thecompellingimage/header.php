<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title();?></title>
<link rel="Shortcut Icon" href="<?php echo bloginfo('template_url'); ?>/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo bloginfo('template_url'); ?>/source/css/main.css" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php wp_head(); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script type="text/javascript"> 
var $jQFlip=jQuery.noConflict(true);
$jQFlip(document).ready(function(){
$jQFlip("ul.product-categories li a").append('<span class="indicator"></span>');
$jQFlip(".pdtdes_dis a.red_txt_normal").click(function(){
	$jQFlip(this).hide();
	$jQFlip(this).prev(".show").hide();	
	$jQFlip(this).next('.pdtdes_hdn').show();
  });
  $jQFlip(".pdtdes_dis .show").click(function(){
	$jQFlip(this).hide();
	$jQFlip(this).next(".red_txt_normal").hide();	
	$jQFlip(this).next(".red_txt_normal").next('.pdtdes_hdn').show();	
  });
  $jQFlip(".pdtdes_hdn a.grey_txt_normal").click(function(){
	$jQFlip(this).parent(".pdtdes_hdn").hide();
	$jQFlip(this).parent(".pdtdes_hdn").prev(".red_txt_normal").show();
	$jQFlip(this).parent(".pdtdes_hdn").prev(".red_txt_normal").prev(".show").show();
  });
});



</script>
</head>
<body>
<div class="wrapper">
<div id="header_row">
<div id="header">
<div id="logo"><a href="/">Logo</a></div>
<?php   if ( function_exists(dynamic_sidebar('Header Right Section')) ) :
            dynamic_sidebar('Header Right Section'); endif; ?>	


</div>	
</div>
<div class="menu_row">
<div class="menu_row_inner">
<?php wp_nav_menu(array('main_nav' => 'main nav menu')); ?>  
<div class="search_container">
<form action="<?php echo bloginfo('url'); ?>" class="search-form" method="get" role="search">
	<input type="text" name="s" class="txt_search">
	<input type="submit" class="btn_search">
</form>
</div>
</div>
</div>
<?php putRevSlider("banner","homepage") ?> 
<div class="line"></div>