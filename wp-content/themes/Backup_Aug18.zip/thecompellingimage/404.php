<?php get_header(); ?>
<div class="row_inner">   
<h1 class="posttitle">Oops! That page wasn't found!</h1>
<div class="entry">
<p>We�re sorry, but the page you were trying to find no longer exists.</p>
</div>
</div>
<?php get_footer(); ?>
