<?php get_header(); ?>
<div class="row_inner details_page">   
<!--Here's where the loop starts-->
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div><!-- Styles container for each post -->
 <h1 class="heading_grey"><?php the_title(); ?></h1>
  <p class="grey_text"><span >Posted on <?php the_time('F j, Y'); ?> by <?php the_author_posts_link(); ?></span></p>
  <div class="grey_text">
    <?php the_content('<p>Continue reading�</p>');?>
  </div>
	<?php comments_template(); ?>  
  </div><!-- Close post box -->
  <?php endwhile; else: ?>
  <div>
    <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
  </div>
  <?php endif; ?>
</div><!-- Close Content -->
<?php get_footer(); ?>
