<div class="row_black_wrapper">
<div class="row_inner great_offer">
<div class="clearfix">
<h1 class="title">Find out more about this great offer!</h1>
<a href="<?php echo bloginfo('url'); ?>/my-account/" class="signup"> Sign Up for Course</a>
</div>
<div class="stripe">
<a><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_wp.png"></a>
<a><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_media.png"></a>
<a><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_canon.png"></a>
<a><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_apple.png"></a>
<a><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_pj.png"></a>
<a><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_tl.png"></a>
<a><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_mk.png"></a>
</div>
</div>
</div>
<div class="row_black_wrapper">
<div class="row_inner footer clearfix">
<span class="copyright">Contact &copy; 2013 compelling image</span>
<ul class="footerlnk">
<li><a>Home</a></li>
<li><a>Partners</a></li>
<li><a>Privacy Policy</a></li>
<li><a>Contact</a></li>
</ul>
</div>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>