<?php get_header(); ?>
<div class="content_row">
<div class="row1">
<div class="txt_row_home">Popular cources</div>

<div class="img_col1">
<div class="col1txt">Photography</div>
<div class="row1img1"> <a class="img_txt1">Course Selection </a><a class="redtxt">Photography,Multimedia....</a></div>
<div class="row1img2"><a class="img_txt1">Portfolio </a></div>
<div class="row2img1"> <a class="img_txt1">What's New?</a></div>
<div class="row2img2"><a class="img_txt1">Featured Instructor</a></div>
</div>
	
<div class="img_col2">
<div class="col1txt">Multimedia</div>
<div class="row3img1"> <a class="img_txt">Upcoming Courses </a></div>
<div class="row3img2"><a class="img_txt">Upcoming Courses </a></div>
<div class="row4img1"> <a class="img_txt">Inspirations</a></div>
<div class="row4img2"><a class="img_txt">Inspirations</a></div>
</div>
</div>
</div>
<div class="get_start_row1_wrapper">
<div class="get_start_row1">
<p class="ptxt"><font color="#8b2317">Get started today</font> - Try a Sample Course for Free!</p>
<p class="txtsmall">Sign up for a sample cource<font color="#8b2317"> 10$ Only </font>sample lesson, complete with related assignment.</p>
<p class="txtmedium">Your Free Lesson Includes:</p>

<ul class="get_start_mnu">
<li><a id="photo"></a></li>
<li><a id="training"></a></li>
<li><a id="schedule"></a></li>
<li><a id="anywhere"></a></li>
</ul>
<ul class="mnutxt">
<li><a href="#">Lesson from professional<br> photographer</a></li>
<li><a href="#">Hands-on, 1-to-1 training</a></li>
<li><a href="#">Flexiblity to meet your<br>schedule</a></li>
<li><a href="#">Work from anywhere in<br>the world</a></li>

</ul>
</div>
</div>

<div class="get_start_black">
<div class="get_start_black_row">
<p class="ptxt"><font color="#8b2317">Get started today</font> - Try a Sample Course for Free!</p>
<p class="txtsmall">Sign up for a sample cource<font color="#8b2317"> 10$ Only </font>sample lesson, complete with related assignment.</p>
<p class="txtmedium">Your Free Lesson Includes:</p>

<ul class="get_start_mnu1">
<li><a id="photo"></a></li>
<li><a id="training"></a></li>
<li><a id="schedule"></a></li>
<li><a id="anywhere"></a></li>
</ul>
<ul class="mnutxt">
<li><a href="#">Lesson from professional<br> photographer</a></li>
<li><a href="#">Hands-on, 1-to-1 training</a></li>
<li><a href="#">Flexiblity to meet your<br>schedule</a></li>
<li><a href="#">Work from anywhere in<br>the world</a></li>
</ul>
</div>
</div>

<div class="findoffer_row">
<div class="findoffer_inner">
<h1 class="title">Find out more about this great offer!</h1>
<a class="signup"> Sign Up for Course</a>
</div>
</div>

<div class="row_black_wrapper overflow_fix">
<div class="row_inner">
<p class="title_red txt_center">Train with the World's Top Pro Photographers and Photoshop Experts!</p>
<p class="title_grey txt_center">Featured Instructors</p>
<ul class="instructor_list">
<li><img src="<?php echo bloginfo('template_url'); ?>/source/images/instruc1.png" alt="John smith"><h2>John Smith</h2><p>Description goes here</p></li>
<li><img src="<?php echo bloginfo('template_url'); ?>/source/images/instruc2.png" alt="Monica"><h2>Monica</h2><p>Description goes here</p></li>
<li><img src="<?php echo bloginfo('template_url'); ?>/source/images/instruc3.png" alt="Abiraham"><h2>Abiraham</h2><p>Description goes here</p></li>
<li><img src="<?php echo bloginfo('template_url'); ?>/source/images/instruc4.png" alt="Linda Mathew"><h2>Linda Mathew</h2><p>Description goes here</p></li>
<li><img src="<?php echo bloginfo('template_url'); ?>/source/images/instruc5.png" alt="James"><h2>James</h2><p>Description goes here</p></li>
<li><img src="<?php echo bloginfo('template_url'); ?>/source/images/instruc6.png" alt="John smith"><h2>John Smith</h2><p>Description goes here</p></li>
</ul>
<div class="para_left">
<p class="title_red_small" style="margin:0">Blog</p>
<p class="title_regular">Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book.
Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book.</p>
</div>
<div class="para_right">
<p class="title_red_small" style="margin:0">White Paper</p>
<p class="title_regular">Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book. Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book.
Lorem Ipsum is simply dummy text of the printing and typesetting industry. when an unknown it to make a type specimen book.</p>
</div>
</div>
</div>

<div class="row_grey_wrapper overflow_fix">
<div class="row_inner">
<p class="title_red_small">Testimonials</p>
<ul class="testimonial">
<li><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_playvideo.png" alt="play video"><p class="desc">Designation will be place here</p></li>
<li>
<div class="about"><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_testimo1.png">"Lorem ipsum is simply dummy text. Lorem ipsum is simply  Lorem ipsum is simply dummy text. Lorem ipsum is simply dummy text"</div>
<div class="title_red_small">Name Will here</div>
<p class="desc">Designation will be place here</p>
</li>
<li>
<div class="about"><img src="<?php echo bloginfo('template_url'); ?>/source/images/img_testimo2.png">"Lorem ipsum is simply dummy text. Lorem ipsum is simply  Lorem ipsum is simply dummy text. Lorem ipsum is simply dummy text"</div>
<div class="title_red_small">Name Will here</div>
<p class="desc">Designation will be place here</p>
</li>
</ul>
</div>
</div>
<?php get_footer(); ?>