<?php get_header(); ?>
<div class="content_row">
<div class="row1">
<div class="txt_row_home">Popular cources</div>
<?php   if ( function_exists(dynamic_sidebar('Popular Cources Section')) ) :
            dynamic_sidebar('Popular Cources Section'); endif; ?>
</div>
</div>
<div class="get_start_row1_wrapper">
<div class="get_start_row1">
<?php   if ( function_exists(dynamic_sidebar('Free Lesson Section')) ) :
            dynamic_sidebar('Free Lesson Section'); endif; ?>	
</div>
</div>
<div class="get_start_black">
<div class="get_start_black_row">
<?php   if ( function_exists(dynamic_sidebar('Free Lesson Section')) ) :
            dynamic_sidebar('Free Lesson Section'); endif; ?>	
</div>
</div>
<div class="findoffer_row">
<div class="findoffer_inner">
<h1 class="title">Find out more about this great offer!</h1>
<a class="signup tdn" href="<?php echo bloginfo('url'); ?>/my-account/"> Sign Up for Course</a>
</div>
</div>
<div class="row_black_wrapper overflow_fix">
<div class="row_inner">
<p class="title_red txt_center">Train with the World's Top Pro Photographers and Photoshop Experts!</p>
<p class="title_grey txt_center">Featured Instructors</p>
<?php   if ( function_exists(dynamic_sidebar('Featured Instructors Section')) ) :
            dynamic_sidebar('Featured Instructors Section'); endif; ?>	
<?php   if ( function_exists(dynamic_sidebar('Featured Instructors Bottom')) ) :
            dynamic_sidebar('Featured Instructors Bottom'); endif; ?>	
</div>
</div>
<div class="row_grey_wrapper overflow_fix">
<div class="row_inner">
<p class="title_red_small">Testimonials</p>
<?php   if ( function_exists(dynamic_sidebar('Testimonials')) ) :
            dynamic_sidebar('Testimonials'); endif; ?>	
</div>
</div>
<?php get_footer(); ?>			