<?php
$dbconn = pg_connect("host=192.168.1.84 port=5432 dbname=test user=postgres ") or die("Unable to connect to postgresSQL");
?>