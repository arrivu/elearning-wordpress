<html>
<head>
<title>Student</title>
</head>
<body>
<form action="submit.php" method="post">
<table align="center" border="0">
<tr><td>Email</td><td> <input type="text" name="email" value=""></td></tr>
<tr><td>Course</td><td> <input type="text" name="course" value=""></td></tr>
<tr><td colspan="2" align="center"><input type="submit" value="Submit" name="submit"></td></tr>
</table>
</form>
</body>
</html>