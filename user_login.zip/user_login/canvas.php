<?php
	$access_token="q3SUMcJqzGG13onCLpbqf20h8rA9EBnOCTTvDGzT4PuwitHUIidyGPEBHQTk4CUX";
	$apiurl="http://canvas.wordpress.com:3000/api/v1";
	
	function post_json($url,$data){
		global $access_token;
		$handle = curl_init();
		$headers = array(
			'Accept: application/json',
			'Content-Type: application/json',
			'Authorization: Bearer '.$access_token
		);
		curl_setopt($handle, CURLOPT_URL, $url);
		curl_setopt($handle, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($handle, CURLOPT_POST, true);
		curl_setopt($handle, CURLOPT_POSTFIELDS, $data);
	    $response = json_decode(curl_exec($handle),TRUE);
	    curl_close($handle);
	    return $response;
	} 

	function lms_create_user($email){
		global $apiurl;
		$data = json_encode(array("user" => array("name" => $email),"pseudonym" => array("unique_id" => $email,"password" => $email)));
		return post_json($apiurl."/accounts/1/users",$data);

	}

	function lms_create_course($course){
		global $apiurl;
		$data = json_encode(array("account_id"=>"1","course" => array( "sis_course_id" => $course,"name" => $course, "public_description" => $course )));
		return post_json($apiurl."/accounts/1/courses",$data);
	}

	function lms_enroll_user($user_lmsid,$course_lmsid){
		global $apiurl;
		$data = json_encode(array("enrollment" => array( "user_id" => $user_lmsid, "type" => "StudentEnrollment", "enrollment_state" => "active", "notify" => "0")));
		return post_json($apiurl."/courses/".$course_lmsid."/enrollments",$data);
	}
?>