<?php
	include("db.php");
	include("canvas.php");
	$user_lmsid="";
	$course_lmsid="";
	$email=trim(strtolower($_POST['email']));
	$query="select * from student where trim(lower(email))='".$email."'";
	$result=pg_query($query);
	if($row=pg_fetch_array($result))	{
		$user_lmsid=$row['lms_id'];		
	}else{
		//create canvas user
		$response=lms_create_user($email);
		if($response['id'] != ""){
			$insert="INSERT INTO student (email, lms_id) VALUES ('".$email."','".$response['id']."')";
			pg_query($insert);
			$user_lmsid=$response['id'];
		}
		
	}	
	
	$course=trim(strtolower($_POST['course']));
	$course_query="select * from course where trim(lower(coursename))='".$course."'";
	$course_result=pg_query($course_query);
	
	if($row=pg_fetch_array($course_result)){
		$course_lmsid=$row['lms_id'];		
	}else{
		//create canvas course
		$response=lms_create_course($course);
		if(isset($response['id'])){
			$insert="INSERT INTO course (coursename, lms_id) VALUES ('".$course."','".$response['id']."')";
			pg_query($insert);
			$course_lmsid=$response['id'];
		}
		
	}			
	if($user_lmsid!="" && $course_lmsid!=""){
		//enroll user to a course
		lms_enroll_user($user_lmsid,$course_lmsid);
	}
	header("Location: code1.php");

?>
