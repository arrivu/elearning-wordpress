CREATE TABLE student
(
  id serial NOT NULL,
  email text,
  lms_id integer
);

